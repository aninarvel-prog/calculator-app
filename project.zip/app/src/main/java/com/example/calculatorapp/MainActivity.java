
package com.example.calculatorapp;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
 @Override
 protected void onCreate(Bundle savedInstanceState){
  super.onCreate(savedInstanceState);
  WebView webView=new WebView(this);
  WebSettings s=webView.getSettings();
  s.setJavaScriptEnabled(true);
  webView.loadUrl("file:///android_asset/index.html");
  setContentView(webView);
 }
}
